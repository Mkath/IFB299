 <?php

	$dbhost 	= "localhost";
	$dbname		= "1008545";
	$dbuser		= "1008545";
	$dbpass		= "IFB299GROUP93";
/*
 $dbhost 	= "localhost";
	$dbname		= "property_management";
	$dbuser		= "root";
	$dbpass		= "6Chain9123";
*/
	?>