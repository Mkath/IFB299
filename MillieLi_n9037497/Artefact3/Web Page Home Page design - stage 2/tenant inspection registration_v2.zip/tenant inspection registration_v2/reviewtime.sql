/*
-- Query: SELECT * FROM rental.reviewcomment
LIMIT 0, 1000

-- Date: 2015-09-10 09:20
*/
INSERT INTO `reviewcomment` (`review`,`time`) VALUES ('','Sat 28 Sep 8:30pm - 9:00am');
